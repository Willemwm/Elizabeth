﻿namespace QuieresCasarteConmigo
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.texto1 = new System.Windows.Forms.Label();
            this.btnNO = new System.Windows.Forms.Button();
            this.btnSi = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.textoeli = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.btnNO);
            this.panel1.Controls.Add(this.btnSi);
            this.panel1.Controls.Add(this.texto1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(597, 287);
            this.panel1.TabIndex = 0;
            // 
            // texto1
            // 
            this.texto1.AccessibleName = "";
            this.texto1.AutoSize = true;
            this.texto1.BackColor = System.Drawing.Color.Transparent;
            this.texto1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texto1.ForeColor = System.Drawing.Color.White;
            this.texto1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.texto1.Location = new System.Drawing.Point(79, 66);
            this.texto1.Name = "texto1";
            this.texto1.Size = new System.Drawing.Size(451, 28);
            this.texto1.TabIndex = 1;
            this.texto1.Text = "Elizabeth ¿Quieres Casarte Conmigo?";
            this.texto1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnNO
            // 
            this.btnNO.BackColor = System.Drawing.Color.White;
            this.btnNO.BackgroundImage = global::QuieresCasarteConmigo.Properties.Resources.Sin_título;
            this.btnNO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnNO.Font = new System.Drawing.Font("Heavitas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNO.ForeColor = System.Drawing.Color.White;
            this.btnNO.Location = new System.Drawing.Point(394, 177);
            this.btnNO.Name = "btnNO";
            this.btnNO.Size = new System.Drawing.Size(70, 35);
            this.btnNO.TabIndex = 3;
            this.btnNO.Text = "NO";
            this.btnNO.UseVisualStyleBackColor = false;
            this.btnNO.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnNO_MouseMove);
            // 
            // btnSi
            // 
            this.btnSi.BackColor = System.Drawing.Color.White;
            this.btnSi.BackgroundImage = global::QuieresCasarteConmigo.Properties.Resources.Sin_título;
            this.btnSi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSi.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnSi.Font = new System.Drawing.Font("Heavitas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSi.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSi.Location = new System.Drawing.Point(145, 177);
            this.btnSi.Name = "btnSi";
            this.btnSi.Size = new System.Drawing.Size(70, 35);
            this.btnSi.TabIndex = 2;
            this.btnSi.Text = "SÍ";
            this.btnSi.UseVisualStyleBackColor = false;
            this.btnSi.Click += new System.EventHandler(this.btnSi_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QuieresCasarteConmigo.Properties.Resources.Sin_título;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(597, 287);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.textoeli);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(597, 287);
            this.panel2.TabIndex = 4;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QuieresCasarteConmigo.Properties.Resources.otra;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(597, 287);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // textoeli
            // 
            this.textoeli.AutoSize = true;
            this.textoeli.BackColor = System.Drawing.Color.Transparent;
            this.textoeli.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.textoeli.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoeli.ForeColor = System.Drawing.Color.White;
            this.textoeli.Location = new System.Drawing.Point(20, 75);
            this.textoeli.Name = "textoeli";
            this.textoeli.Size = new System.Drawing.Size(0, 17);
            this.textoeli.TabIndex = 1;
            this.textoeli.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.textoeli.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Font = new System.Drawing.Font("Nexa Heavy", 8.249999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = global::QuieresCasarteConmigo.Properties.Resources.otra;
            this.button1.Location = new System.Drawing.Point(270, 238);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 37);
            this.button1.TabIndex = 2;
            this.button1.Text = "CERRAR";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(12, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(565, 102);
            this.label1.TabIndex = 3;
            this.label1.Text = resources.GetString("label1.Text");
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 287);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label texto1;
        private System.Windows.Forms.Button btnSi;
        private System.Windows.Forms.Button btnNO;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label textoeli;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}

